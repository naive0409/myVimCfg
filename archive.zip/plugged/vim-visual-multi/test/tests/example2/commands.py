# 2x C-n, c
keys('\<C-n>')
keys('\<C-n>')
keys('C')
keys('hello')
keys('\<Esc>')
